#!/bin/bash
git clone git://github.com/jgoppert/arduino-cmake.git tmp
cp -rf tmp/cmake/* .
rm -rf tmp
